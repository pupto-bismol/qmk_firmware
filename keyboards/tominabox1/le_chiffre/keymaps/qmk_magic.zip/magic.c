#include "magic.h"
#include "deferred_exec.h"

int rep_key_count = 0;
int alt_rep_key_count = 0;
int last_key_pressed_time = 0;
int prev_keys_queue[PREV_KEYS_QUEUE_SIZE] = {KC_NO};
deferred_token magic_timeout_token = INVALID_DEFERRED_TOKEN;

////////////////////////////////////////////////////////////////////////////////
uint32_t enqueue_space(uint32_t trigger_time, void *cb_arg)
{
    enqueue(KC_SPC);
    return 0;
}
////////////////////////////////////////////////////////////////////////////////
void refresh_token(void)
{
    if (magic_timeout_token != INVALID_DEFERRED_TOKEN)
        cancel_deferred_exec(magic_timeout_token);
    magic_timeout_token = defer_exec(MAGIC_KEY_TIMEOUT, enqueue_space, NULL);
}
////////////////////////////////////////////////////////////////////////////////
void record_send_string(const char *str)
{
	for (int i = 0; str[i] != '\0'; i++) {
        if (65 <= str[i] && str[i] <= 90) enqueue(str[i] - 61);
        else if (97 <= str[i] && str[i] <= 122) enqueue(str[i] - 93);
    }
    SEND_STRING(str);
}
////////////////////////////////////////////////////////////////////////////////
void enqueue(int keycode)
{
    for (int i = 0; i < PREV_KEYS_QUEUE_SIZE - 1; i += 1)
        prev_keys_queue[i] = prev_keys_queue[i + 1];
    prev_keys_queue[PREV_KEYS_QUEUE_SIZE - 1] = keycode;
}
////////////////////////////////////////////////////////////////////////////////
void dequeue(void)
{
    set_last_keycode(prev_keys_queue[PREV_KEYS_QUEUE_SIZE - 1]);
    for (int i = PREV_KEYS_QUEUE_SIZE - 1; i > 0; i -= 1)
        prev_keys_queue[i] = prev_keys_queue[i - 1];
    prev_keys_queue[0] = KC_NO;
}
////////////////////////////////////////////////////////////////////////////////
uint16_t normalize_keycode(uint16_t keycode)
{
    if (IS_QK_MOD_TAP(keycode))
		return QK_MOD_TAP_GET_TAP_KEYCODE(keycode);
    if (IS_QK_LAYER_TAP(keycode))
		return QK_LAYER_TAP_GET_TAP_KEYCODE(keycode);
    return keycode;
}
////////////////////////////////////////////////////////////////////////////////
bool remember_last_key_user(uint16_t keycode, keyrecord_t* record, uint8_t* mods)
{
    keycode = normalize_keycode(keycode);

    if (keycode == KC_BSPC)
        dequeue();

    if ((*mods & MOD_MASK_CTRL) &&
        ((keycode == KC_BSPC && record->tap.count) || (keycode == KC_BSPC)))
		keycode = KC_SPC;

    switch (keycode) {
        case KC_ENT:
		case KC_TAB:
        //case TD_EQL:
        //case TD_DQT:        
        //case TD_BSLS:
        //case US_CLER:
        //case HK_RMWR:
            keycode = KC_SPC;
    }
    switch (keycode) {
        case US_REP:
        case KC_BSPC:
        case US_AREP:
            return false;
    }
    enqueue(keycode);
    return true;
}
////////////////////////////////////////////////////////////////////////////////
void process_magic_key(void)
{
    if (alt_rep_key_count >= 2) {
        switch (queue(-4)) {
            quadruple_magic_case(KC_SPC, KC_A, KC_L, KC_R, "eady");
        }
        switch (queue(-3)) {
            triple_magic_case(KC_Q, KC_U, KC_E, "ue");
            default: SEND_STRING("n"); return;
        }
    }
    switch (queue(-4)) {
        quadruple_magic_case(KC_O,   KC_L, KC_I, KC_C, "y");
        quadruple_magic_case(KC_U,   KC_R, KC_A, KC_C, "y");
        quadruple_magic_case(KC_R,   KC_M, KC_A, KC_C, "y");
        quadruple_magic_case(KC_SPC, KC_R, KC_E, KC_C, "y");
        quadruple_magic_case(KC_C,   KC_R, KC_A, KC_C, "y");
    }
    switch (queue(-3)) {
        triple_magic_switch(KC_SPC,
            double_magic_switch(KC_A,
                magic_case(KC_L, "r");
                magic_case(KC_N, "other");
            );
            double_magic_case(KC_T, KC_I, "me");
            double_magic_case(KC_I, KC_N, "form");
            double_magic_case(KC_E, KC_X, "ample");
        );
        triple_magic_switch(KC_B,
            double_magic_switch(KC_E,
                magic_case(KC_C, "ome");
                magic_case(KC_T, "ween");
                magic_case(KC_L, "ieve");
            );
        );
        triple_magic_case(KC_V, KC_A, KC_C, "y");
        triple_magic_case(KC_G, KC_A, KC_C, "y");
        triple_magic_case(KC_S, KC_Y, KC_S, "tem");
        triple_magic_case(KC_O, KC_B, KC_V, "ious");
    }

    switch (queue(-2)) {
        double_magic_switch(KC_M,
            magic_case(KC_P, "l");
			// m_d 2u skipgrams
            magic_case(KC_A, "d");
            magic_case(KC_O, "d");
            magic_case(KC_E, "d");
            magic_case(KC_U, "d");
            magic_case(KC_I, "d");
        );
		// d_m 2u skipgrams
		double_magic_switch(KC_D,
            magic_case(KC_A, "m");
            magic_case(KC_O, "m");
            magic_case(KC_E, "m");
            magic_case(KC_U, "m");
            magic_case(KC_I, "m");
        );
        double_magic_switch(KC_O,
            magic_case(KC_C, "k");
            magic_case(KC_T, "her");
        );
        double_magic_switch(KC_V,
            magic_case(KC_I, "ew");
            magic_case(KC_E, "ry");
            magic_case(KC_A, "lue");
        );
        double_magic_switch(KC_SPC,
            magic_case(KC_T, "hat");
            magic_case(KC_E, "nt");
            magic_case(KC_Y, "ou'");
            magic_case(KC_W, "hich'");
        );
        double_magic_switch(KC_U,
            magic_case(KC_C, "k");
			magic_case(KC_P, "date");
			// u_e skipgrams
			magic_case(KC_T, "e");
			magic_case(KC_S, "e");
			magic_case(KC_D, "e");
			magic_case(KC_B, "e");
			magic_case(KC_L, "e");
			magic_case(KC_R, "e");
			magic_case(KC_M, "e");
			magic_case(KC_N, "e");
        );
		double_magic_case(KC_J, KC_O, "in");
		double_magic_case(KC_W, KC_A, "s");
        double_magic_case(KC_I, KC_C, "k");        
        double_magic_case(KC_A, KC_C, "k");
        double_magic_case(KC_E, KC_C, "k");
		double_magic_case(KC_C, KC_Y, "c");
        double_magic_case(KC_B, KC_E, "en");
        double_magic_case(KC_S, KC_O, "me");
        double_magic_case(KC_L, KC_I, "st");
        double_magic_case(KC_P, KC_E, "ople");
    }

    switch (queue(-1)) {
		// sfbs
        magic_case(KC_S,   "c");
        magic_case(KC_C,   "s");
        magic_case(KC_U,   "e");
        magic_case(KC_E,   "u");
        magic_case(KC_P,   "h");
        magic_case(KC_R,   "l");
        magic_case(KC_O,   "a");
		magic_case(KC_A,   "o");
        magic_case(KC_G,   "s");
        magic_case(KC_H,   "y");
        magic_case(KC_W,   "s");
		// ngrams
		magic_case(KC_Y,   "ing");
        magic_case(KC_I,   "on");
        magic_case(KC_V,   "er");
        magic_case(KC_Q,   "ue");
        magic_case(KC_N,   "ly");
        //magic_case(KC_M,   "ent");
        magic_case(KC_J,   "ust");
        magic_case(KC_Z,   "one");
        magic_case(KC_SPC, "the");
        magic_case(KC_T,   "ment");
        magic_case(KC_F,   "irst");
        magic_case(KC_B,   "efore");
    }
}
////////////////////////////////////////////////////////////////////////////////
bool magic_pr(uint16_t keycode, keyrecord_t *record, bool *return_value)
{
    *return_value = false;
    if (record->event.pressed) {
        if (keycode != US_REP && keycode != US_AREP) {
            last_key_pressed_time = timer_read();
            refresh_token();
        }
        if (keycode != US_REP)
			rep_key_count = 0;
        else
			rep_key_count += 1;

        if (keycode != US_AREP)
			alt_rep_key_count = 0;
        else
			alt_rep_key_count += 1;
    }
    switch (keycode) {
        /*case US_REP:
            if (record->event.pressed)
                process_rep_key();
            return true;*/
        case US_AREP:
            if (record->event.pressed)
                process_magic_key();
            return true;
    }
    return false;
}